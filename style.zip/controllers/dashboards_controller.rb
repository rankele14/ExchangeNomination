class DashboardsController < ApplicationController
    def show
    end
  end